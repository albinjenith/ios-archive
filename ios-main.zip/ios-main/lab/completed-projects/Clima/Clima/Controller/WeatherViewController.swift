//
//  ViewController.swift
//  Clima
//
//  Created by Jared Chen on 2024/3/20.
//

import UIKit
import CoreLocation

class WeatherViewController: UIViewController {//, UITextFieldDelegate, WeatherManagerDelegate{

    @IBOutlet weak var conditionImageView: UIImageView!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var searchTextField: UITextField!
    
    var weatherManager = WeatherManager()
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        searchTextField.delegate = self
        //weatherManager.vc = self
        weatherManager.delegate = self
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        //locationManager.startUpdatingLocation() - for apps such as running app which keeps monitoring the location.
        locationManager.requestLocation() //request the location for one time.
    }
    
//    //triggered each time we type a character in the search text field
//    @IBAction func searchTextFieldEditingChanged(_ sender: UITextField) {
//        print(sender.text!)
//    }
//
//    //Triggered when endEditing(true) is called
//    @IBAction func searchTextFieldEditingDidEnd(_ sender: UITextField) {
//        print(searchTextField.text!)
//    }
//
//    //Not being triggered, nothing to do with delegate
//    @IBAction func searchTextFieldValueChanged(_ sender: UITextField) {
//        print(searchTextField.text!)
//    }
}

//MARK: - UITextFieldDelegate
extension WeatherViewController: UITextFieldDelegate{
    @IBAction func searchButtonPressed(_ sender: UIButton) {
        searchTextField.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.endEditing(true)
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if let city = textField.text{
            weatherManager.fetchWeather(cityName: city)
        }
    }
}

//MARK: - WeatherManagerDelegate
extension WeatherViewController: WeatherManagerDelegate{
    func didUpdateWeather(_ weather: WeatherModel) {
        let conditionName = weather.conditionName
        let temp = weather.temperatureString
        let name = weather.cityName
        
        DispatchQueue.main.async {
            self.conditionImageView.image = UIImage(systemName: conditionName)
            self.temperatureLabel.text = temp
            self.cityLabel.text = name
        }
    }
    
    func didFailWithError(_ error: Error) {
        //display error message in the UI, so user can know what's going on.
        //for example, inform user there is no internet connection.
        print(error)
    }
}

//MARK: - CLLocationManagerDelegate
extension WeatherViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            locationManager.stopUpdatingLocation()
            
            let lat = location.coordinate.latitude
            let lon = location.coordinate.longitude
            
            weatherManager.fetchWeather(lat: lat, lon: lon)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    
    @IBAction func locationButtonPressed(_ sender: UIButton) {
        locationManager.requestLocation()
    }
}



