# Todoey ✓


## What you will create

A todolist app to keep track of all your tasks.

## What you will learn

* Learn about different ways to persist data locally including UserDefaults and Core Data
* How to work with iOS Table Views
* how to work with iOS Navigation Controller

