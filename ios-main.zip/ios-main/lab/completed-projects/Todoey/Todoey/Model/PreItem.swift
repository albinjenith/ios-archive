//
//  PreItem.swift
//  Todoey
//
//  Created by Jared Chen on 2024/4/1.
//

import Foundation

struct PreItem: Encodable, Decodable{
    var title:String = ""
    var done:Bool = false
    var date:Date = Date()
}
