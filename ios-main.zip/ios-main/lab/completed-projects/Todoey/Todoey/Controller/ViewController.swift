//
//  ViewController.swift
//  Todoey
//
//  Created by Jared Chen on 2024/3/20.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    //var itemArray = ["Buy Egg", "Buy Vegi", "Buy Meat"]
    var itemArray = [Item]()
    var selectedCategory : Category?
    
    //let defaults = UserDefaults.standard
    let dataFilePath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("Items.plist")
    
    //this wont work because AppDelegate is a class, not an instance.
    //let context = AppDelegate.persistentContainer.viewContext
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
//        if let items = defaults.array(forKey: "Items") as? [String] {
//            itemArray = items
//        }
        
//        itemArray.append(Item(title: "Buy Egg", done: false))
//        itemArray.append(Item(title: "Buy Meat", done: false))
//        itemArray.append(Item(title: "Buy Fish", done: false))
        
        //print(dataFilePath!)
        
        tableView.dataSource = self
        tableView.delegate = self
        
        loadItems()
    }
        
    @IBAction func addButtonPressed(_ sender: UIBarButtonItem) {
        var textField = UITextField()
        
        let alert = UIAlertController(title: "Add New Todoey Item", message: "", preferredStyle: .alert)
    
        //The button being displayed
        let action = UIAlertAction(title: "Add Item", style: .default){action in
            //what should happen once the user clicks the Add Item button
//            if let newItem = textField.text {
//                self.itemArray.append(newItem)
//
//                self.defaults.set(self.itemArray, forKey: "Items")
//
//                self.tableView.reloadData()
//            }
            
//            if let title = textField.text {
//                self.itemArray.append(Item(title: title, done: false))
//                self.tableView.reloadData()
//            }
            
            if let title = textField.text {
                let item = Item(context: self.context)
                item.title = title
                item.done = false
                item.parentCategory = self.selectedCategory
                
                self.itemArray.append(item)
                //self.itemArray.append(Item(title: title, done: false))
                
                //Store array to UserDefaults
                //self.defaults.set(self.itemArray, forKey: "Items")
                
//                let encoder = PropertyListEncoder()
//                do{
//                    let data = try encoder.encode(self.itemArray)
//                    try data.write(to: self.dataFilePath!)
//                }catch{
//                    print(error)
//                }
                self.saveItems()
                self.tableView.reloadData()
            }
        }
        
        alert.addAction(action)
        
        //add text field to alert
        alert.addTextField(){alertTextField in
            alertTextField.placeholder = "Create new item"
            textField = alertTextField
        }
        
        present(alert, animated: true)
    }
    
    func loadItems(with request:NSFetchRequest<Item> = Item.fetchRequest()){
        //read from userdefaults
        //        if let items = defaults.array(forKey: "Items") as? [Item] {
        //            itemArray = items
        //        }
        
//        do{
//            read from plist
//            let data = try Data(contentsOf: self.dataFilePath!)
//            let decoder = PropertyListDecoder()
//            itemArray = try decoder.decode([Item].self, from: data)
//        }catch{
//            print(error)
//        }
        
        let categoryPredicate = NSPredicate(format: "parentCategory.name MATCHES %@", selectedCategory!.name!)
        
        if let predicate = request.predicate {
            let compoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [predicate, categoryPredicate])
            
            request.predicate = compoundPredicate
        }else{
            request.predicate = categoryPredicate
        }
        
        do{
            //must speicfy the data type for this case
            //let request : NSFetchRequest<Item> = Item.fetchRequest()
            itemArray = try context.fetch(request)
            tableView.reloadData()
        }catch{
            print("Error fetching data \(error)")
        }
    }
    
    func saveItems(){
//        let encoder = PropertyListEncoder()
//        do{
//            let data = try encoder.encode(self.itemArray)
//            try data.write(to: self.dataFilePath!)
//        }catch{
//            print(error)
//        }
        
        do{
            try context.save()
        }catch{
            print("Error saving data \(error)")
        }
    }
}

//MARK: - UITableViewDataSource
extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TodoItemCell", for: indexPath)
        
        cell.textLabel?.text = itemArray[indexPath.row].title
        cell.accessoryType = itemArray[indexPath.row].done ? .checkmark: .none
        
        return cell
    }
}

//MARK: - UITableViewDelegate
extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print(itemArray[indexPath.row])
        
        //1.
        //tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        
        //2.
//        if let cell = tableView.cellForRow(at: indexPath) {
//            if cell.accessoryType == .checkmark {
//                cell.accessoryType = .none
//            }else{
//                cell.accessoryType = .checkmark
//            }
//        }
        
        //3. Ternary Operator
//        if let cell = tableView.cellForRow(at: indexPath) {
//            cell.accessoryType = cell.accessoryType == .none ? .checkmark : .none
//        }
        
        //itemArray[indexPath.row].setValue(!itemArray[indexPath.row].done, forKey: "done")
        itemArray[indexPath.row].done = itemArray[indexPath.row].done ? false: true
        //delete items
        //context.delete(itemArray[indexPath.row])
        //itemArray.remove(at: indexPath.row)
        
//        let encoder = PropertyListEncoder()
//        do{
//            let data = try encoder.encode(self.itemArray)
//            try data.write(to: self.dataFilePath!)
//        }catch{
//            print(error)
//        }
        saveItems()
        tableView.reloadData()
        
        //make the row selected and deselected in a flash
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

//MARK: - UISearchBarDelegate
extension ViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if let searchText = searchBar.text {
            let request:NSFetchRequest<Item> = Item.fetchRequest()
            
            //case sensitive
            //let predicate = NSPredicate(format: "title CONTAINS[c] %@", searchText)
            let predicate = NSPredicate(format: "title CONTAINS %@", searchText)
            request.predicate = predicate
            
            let softDescriptor = NSSortDescriptor(key: "title", ascending: true)
            request.sortDescriptors = [softDescriptor]
            
            loadItems(with: request)
//                        do{
//                            itemArray = try context.fetch(request)
//                        }catch{
//                            print(error)
//                        }
            //tableView.reloadData()
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBar.text?.count == 0 {
            loadItems()

            DispatchQueue.main.async {
                searchBar.resignFirstResponder()
            }

        }
    }
}
