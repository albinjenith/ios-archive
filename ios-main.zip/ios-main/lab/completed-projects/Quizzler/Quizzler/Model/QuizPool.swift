//
//  QuestionPool.swift
//  Quizzler
//
//  Created by Jared Chen on 2024/3/19.
//  Copyright © 2024 The App Brewery. All rights reserved.
//

struct QuizPool{
    let questions = [
        Question("Two + Three equals Five?", "True"),
        Question("Three - One equals One?", "False"),
        Question("Four + Two equals Six?", "True")
    ]

    var questionIndex = 0
    var score = 0
    
    func getQuestion() -> String{
        return questions[questionIndex].question
    }
    
    mutating func nextQuestion() {
        if questionIndex < questions.count - 1 {
            questionIndex += 1
        }else{
            questionIndex = 0
            score = 0
        }
    }
    
    mutating func checkAnswer(selectedAnswer: String) -> Bool{
        if selectedAnswer == questions[questionIndex].answer {
            score += 1
            return true
        }
           
        return false
    }
    
    func getProgress() -> Float {
        return Float(questionIndex+1) / Float(questions.count)
    }
    
    func getScore() -> Int {
        return score
    }
}
