//
//  Question.swift
//  Quizzler
//
//  Created by Jared Chen on 2024/3/19.
//  Copyright © 2024 The App Brewery. All rights reserved.
//

struct Question{
    var question:String
    var answer:String
    
    init(_ question:String, _ answer:String){
        self.question = question
        self.answer = answer
    }
}
