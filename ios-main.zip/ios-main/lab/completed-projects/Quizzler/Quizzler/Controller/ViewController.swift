//
//  ViewController.swift
//  Quizzler-iOS13
//
//  Created by Angela Yu on 12/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var questionText: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var trueButton: UIButton!
    @IBOutlet weak var falseButton: UIButton!
    @IBOutlet weak var scoreLabel: UILabel!
    
    //let questions = ["Two + Three equals Five?", "Three - One equals One?", "Four + Two equals Six?"]
    
//    let questions = [
//        ["Two + Three equals Five?", "True"],
//        ["Three - One equals One?", "False"],
//        ["Four + Two equals Six?", "True"]
//    ]
    
//    let questions = [
//        Question("Two + Three equals Five?", "True"),
//        Question("Three - One equals One?", "False"),
//        Question("Four + Two equals Six?", "True")
//    ]
//
//    var questionIndex = 0
    
    var quizPool = QuizPool()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //questionText.text = "This is the first question!"
        //questionText.text = questions[questionIndex].question
        
        updateUI()
    }

    @IBAction func answerButtonPressed(_ sender: UIButton) {
        let selectedAnswer = sender.currentTitle!
        
        if quizPool.checkAnswer(selectedAnswer: selectedAnswer) {
            sender.backgroundColor = UIColor.green
        }else{
            sender.backgroundColor = UIColor.red
        }
//        if selectedAnswer == questions[questionIndex].answer {
//            print("Answer Correct!")
//            sender.backgroundColor = UIColor.green
//        }else{
//            print("Answer Wrong!")
//            sender.backgroundColor = UIColor.red
//        }
    
        quizPool.nextQuestion()
//        if questionIndex < questions.count - 1 {
//            questionIndex += 1
//        } else {
//            questionIndex = 0
//        }
        
//        questionText.text = questions[questionIndex].question
//        sender.backgroundColor = UIColor.clear
        
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(updateUI), userInfo: nil, repeats: false)
    }
    
    @objc func updateUI(){
        questionText.text = quizPool.getQuestion()
        //questionText.text = questions[questionIndex].question
        
        trueButton.backgroundColor = UIColor.clear
        falseButton.backgroundColor = UIColor.clear
        
        progressBar.progress = quizPool.getProgress()
        //progressBar.progress = Float(questionIndex+1) / Float(questions.count)
        
        scoreLabel.text = "Score: \(quizPool.getScore())"
    }
}

