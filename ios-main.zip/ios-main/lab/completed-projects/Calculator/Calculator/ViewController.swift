//
//  AppDelegate.swift
//  Calculator
//
//  Created by Jared Chen on 04/22/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

