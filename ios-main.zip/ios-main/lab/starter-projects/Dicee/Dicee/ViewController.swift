//
//  ViewController.swift
//  Dicee
//
//  Created by Jared Chen on 2024/3/20.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstDiceImageView: UIImageView!
    
    @IBOutlet weak var secondDiceImageView: UIImageView!
    
    let diceImages = [
        UIImage(named :"DiceOne"),
        UIImage(named :"DiceTwo"),
        UIImage(named :"DiceThree"),
        UIImage(named :"DiceFour"),
        UIImage(named :"DiceFive"),
        UIImage(named :"DiceSix"),
    ]
    var leftDiceIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //firstDiceImageView.image = UIImage(named:"DiceTwo")
    }

    @IBAction func rollButtonClicked(_ sender: UIButton) {
        print("roll button clicked");
        //leftDiceIndex = leftDiceIndex >= 5 ? 0 : leftDiceIndex + 1
        
        firstDiceImageView.image = diceImages[Int.random(in: 0...5)]
        secondDiceImageView.image = diceImages[Int.random(in: 0...5)]    }
    
}

