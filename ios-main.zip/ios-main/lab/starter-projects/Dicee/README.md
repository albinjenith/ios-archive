# Dicee

## Our Goal

The objective of this tutorial is to introduce you to the core programming concepts that will form the foundation of most of the apps you’ll build in the future. This app will teach you a lot of important programming knowledge, while building a neat dice app.

## What you will create

We’re going to make a Las Vegas dice app. You can make the die roll at the press of a button or by shaking your phone. With this app in your pocket, you’ll be fully set up to settle any score on the go!


## What you will learn

* Create an app with behaviour and functionality.
* Create links between the Interface Builder files and code using IBActions and IBOutlets.
* Get familiar with the Xcode code editor.
* Understand and use Swift constants and variables.
* Understand and use collection types such as Swift arrays.
* Learn about randomisation and how to generate random numbers in Swift.
* Learn about Auto Layout and Size classes.

