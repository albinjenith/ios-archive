//
//  ViewController.swift
//  BMI Calculator
//
//  Created by Jared Chen on 2024/3/20.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var heightSlider: UISlider!
    
    @IBOutlet weak var weightSlider: UISlider!
    
    @IBOutlet weak var heightLabel: UILabel!
    
    @IBOutlet weak var weightLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func heightChanged(_ sender: UISlider) {
        let height = String (format: "%.2f",sender.value)
        heightLabel.text = "\(height)m"
    }
    
    
    @IBAction func weightChanged(_ sender: UISlider) {
        let weight = String (format : "%.1f", sender.value)
        weightLabel.text = "\(weight)Kg"
    }
    
    @IBAction func calculateBMI(_ sender: UIButton) {
        
        self.performSegue(withIdentifier: "goToResult", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let height = heightSlider.value;
        let weight = weightSlider.value;
        let bmiValue = weight/(height * height);
        (segue.destination as! ResultViewController).bmiVal = String(format: "%.1f",bmiValue)
        
    }}

