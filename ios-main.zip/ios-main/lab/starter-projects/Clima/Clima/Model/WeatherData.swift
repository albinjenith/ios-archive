//
//  WeatherData.swift
//  Clima
//
//  Created by admin on 27/3/25.
//

import Foundation

struct WeatherData : Decodable{
    let coord : Coord
    let weather : [Weather]
    let main : Main
    let name : String
}

struct Coord : Decodable{
    let lon : Float
    let lat : Float
}

struct Weather : Decodable{
    let id : Int
    let description : String
}

struct Main :Decodable {
    let temp : Float
}
