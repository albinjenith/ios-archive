//
//  ViewController.swift
//  Clima
//
//  Created by Jared Chen on 2024/3/20.
//

import UIKit
import CoreLocation



class WeatherViewController: UIViewController, UITextFieldDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var conditionImageView: UIImageView!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    
    @IBOutlet weak var searchTextField: UITextField!
    let locationManager = CLLocationManager()
    let weatherURL = "https://api.openweathermap.org/data/2.5/weather?appid=11ded175e6fc6a42d5263910c6b70fce&units=metric"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchTextField.delegate = self
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()        // Do any additional setup after loading the view.
    }
    
    @IBAction func getCurrentLocation(_ sender: UIButton) {
        locationManager.requestLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last
            
        if location != nil {
            locationManager.stopUpdatingLocation()
            
            let lat = location!.coordinate.latitude
            let lon = location!.coordinate.longitude
            
            print("lat is \(lat) lon is \(lon)")
            let urlString = "\(weatherURL)&lon=\(lon)&lat=\(lat)"
            fetchWeather(urlString: urlString)
        }
    }
        
    func locationManager(_ manager: CLLocationManager, didFailWithError error: any Error) {
        print(error)
    }
    
    @IBAction func searchWeather(_ sender: UIButton) {
        //print("Current input city is \(searchTextField.text)")
        
        let cityName = searchTextField.text
        if cityName != nil {
            let urlString = "\(weatherURL)&q=\(cityName!)"
            fetchWeather(urlString: urlString)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let cityName = searchTextField.text
        if cityName != nil {
            let urlString = "\(weatherURL)&q=\(cityName!)"
            fetchWeather(urlString: urlString)
        }
        return true;
    }
    
    func fetchWeather(urlString: String){
            //make api calls
                
        //URLSession
        //1. Create URL object
        let url = URL(string: urlString)
        
        if url != nil {
            //2. Create URL Session
            let session = URLSession(configuration: .default)
            
            //3. Give the session a task
            let task = session.dataTask(with: url!, completionHandler: handleResponse(data:response:error:))
            
            //4. Start the task
            task.resume()
        }else{
            print("invalid url...")
        }
    }
    
    func handleResponse(data:Data?, response: URLResponse?, error:Error?) -> Void{
        //parse the json data
        if error != nil {
            print(error!)
            return
        }
        
        if data != nil {
            let dataString = String(data: data!, encoding: .utf8)
            print(dataString!)
            do {
                let decoder = JSONDecoder()
                let decodeData = try decoder.decode(WeatherData.self, from: data!)
                let name = decodeData.name;
                let id = decodeData.weather[0].id
                let temp = decodeData.main.temp
                let conditionName = getConditionName(weatherId: id)
                print("\(name),\(id),\(temp)")
                
                DispatchQueue.main.async{
                                    self.cityLabel.text = name
                                    self.temperatureLabel.text = String(format:"%.1f", temp)
                                    self.conditionImageView.image = UIImage(systemName: conditionName)
                                }            }catch {
                print(error)
            }
        }
    }
    
    func getConditionName(weatherId: Int) -> String{
        switch(weatherId){
                case 200...232:
                    return "cloud.bolt"
                case 300...321:
                    return "cloud.drizzle"
                case 500...531:
                    return "cloud.rain"
                case 600...622:
                    return "cloud.snow"
                case 701...781:
                    return "cloud.fog"
                case 800:
                    return "sun.max"
                case 801...804:
                    return "cloud"
                default:
                    return "cloud"
                }
            }
}

