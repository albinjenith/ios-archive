//
//  Question.swift
//  Quizzler
//
//  Created by admin on 26/3/25.
//  Copyright © 2025 The App Brewery. All rights reserved.
//

import Foundation

struct Question{
    var question:String
    var answer:String
}
