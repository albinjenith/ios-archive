//
//  QuestionManager.swift
//  Quizzler
//
//  Created by admin on 26/3/25.
//  Copyright © 2025 The App Brewery. All rights reserved.
//

import Foundation
struct QuestionManager{
    let questions = [
        Question(question: "Two + Three equals Five?", answer: "True"),
        Question(question: "Three - One equals One?", answer: "False"),
        Question(question: "Four + Two equals Six?", answer: "True")
    ]
    
    var questionIndex = 0;
    var score = 0;
    
    func getQuestion() -> String {
        return questions[questionIndex].question
    }
    
    mutating func nextQuestion() {
        if questionIndex < questions.count - 1{
            questionIndex = questionIndex + 1
        }else{
            questionIndex = 0
            score = 0
        }
    }
    
    mutating func checkAnswer(selectedAnswer: String){
        if selectedAnswer == questions[questionIndex].answer {
            score = score + 1
        }
    }
    
    func getScore() -> Int {
        return score
    }
    
    func getProcess() -> Float {
        return Float(questionIndex+1)/Float(questions.count)
    }
}
