//
//  ViewController.swift
//  Quizzler
//
//  Created by Jared Chen on 2024/3/20.
//


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var questionTextLabel: UILabel!
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    @IBOutlet weak var scoreLabel: UILabel!
    
    var questionManager = QuestionManager()
    
//    let questions = [
//        "Two + Three equals Five?",
//        "Three - One equals One?",
//        "Four + Two equals Six?"
//    ]
//
//    let answers = [true, false, true]
    
//    var questionIndex = 0
//    var score = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //questionTextLabel.text = questions[questionIndex].question
        questionTextLabel.text = questionManager.getQuestion();
        progressBar.progress = 0.0;
        scoreLabel.text = "Score: 0"
    }


    @IBAction func answerBtnPressed(_ sender: UIButton) {
        let selectedAnswer = sender.currentTitle!
//        print("The answer selected is \(answer)")
//        print("The correct answer is \(questions[questionIndex].answer)")
//
//        if answer == questions[questionIndex].answer {
//            score = score + 1
//        }
        questionManager.checkAnswer(selectedAnswer: selectedAnswer)
        scoreLabel.text = "Score: \(questionManager.getScore())"
        
        //Challenge
//        if questionIndex < questions.count - 1 {
//            questionIndex = questionIndex + 1
//        }else{
//            questionIndex = 0
//        }
        questionManager.nextQuestion()
        
        //questionTextLabel.text = questions[questionIndex].question
        questionTextLabel.text = questionManager.getQuestion()
        progressBar.progress = questionManager.getProcess()
    }
}
