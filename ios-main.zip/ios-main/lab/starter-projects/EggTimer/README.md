# Egg Timer

## What You'll Make

You’ll be building a beautiful egg timer app to boil your eggs to perfection depending on how you prefer your eggs. 

## What you will learn

* Conditional statements - IF/ELSE
* Conditional statements - Switch
* Swift Collection types - Dictionaries
* The Swift Timer API
* Functions with inputs & outputs
* Learn about Optionals
* How to use the ProgressView


