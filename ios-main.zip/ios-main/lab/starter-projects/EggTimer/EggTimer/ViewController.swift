//
//  ViewController.swift
//  EggTimer
//
//  Created by Jared Chen on 2024/3/20.
//

import UIKit

class ViewController: UIViewController {
    
    var totalTime = 0;
    var remainTime = 0;
    var timer = Timer();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        progressBar.progress = 0.0
    }
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    @IBOutlet weak var tileLabel: UILabel!
    
    @IBAction func hardnessSelected(_ sender: UIButton) {
        let title = sender.currentTitle!//nil = null
        timer.invalidate()
        progressBar.progress = 0.0
        tileLabel.text = title + " boiled eggs"
        switch title {
        case "Soft":
            totalTime = 300
        case "Medium":
            totalTime = 480
        default:
            totalTime = 720
        }
        remainTime = totalTime
        
        print("Total cooking time is \(totalTime) seconds...")
        
        Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer),  userInfo: nil , repeats: true)

    }
    
    
    @objc func updateTimer () {
        if remainTime > 0 {
            print("\(remainTime) seconds remaining...")
            remainTime = remainTime - 1;
            progressBar.progress = Float(totalTime - remainTime) / Float(totalTime)
        }else{
            print("Time's up!!!")
        }
        
    }
}
