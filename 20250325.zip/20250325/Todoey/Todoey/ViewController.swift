
//
//  ViewController.swift
//  Todoey
//
//  Created by admin on 27/3/25.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @IBOutlet weak var tableView: UITableView!
    
    
    //tell the table view how many item you should expect
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }
        
        //tell the table view how to render each cell for each item
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TodoItemCell", for: indexPath)
            
            let label = cell.textLabel
            
            if label != nil {
                label!.text = itemArray[indexPath.row].title
            }
            if itemArray[indexPath.row].done {
                cell.accessoryType = .checkmark
            }else{
                cell.accessoryType = .none
            }
            return cell
        }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if itemArray[indexPath.row].done {
            itemArray[indexPath.row].done = false
        }else{
            itemArray[indexPath.row].done = true
        }
        
        tableView.reloadData()
    }
    
    // var itemArray = [
     //    TodoItem(title: "Buy Meat", done: false),
      //          TodoItem(title: "Buy Fruit", done: false),
        //        TodoItem(title: "Buy Veges", done: false)    ]

     var itemArray = [Item]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        fetchItems()
    }
    
    func fetchItems(){
            do{
                let request = Item.fetchRequest()
                itemArray = try context.fetch(request)
                
                tableView.reloadData()
            }catch{
                print(error)
            }
        }
   

    @IBAction func addButtonPressed(_ sender: UIBarButtonItem) {
        
        let alert = UIAlertController(title: "Add New Item", message: "", preferredStyle: .alert)
        
        alert.addTextField(configurationHandler: configureTextField(alertTextField:))
        
        let action = UIAlertAction(title: "Add Item", style: .default, handler: addNewItem(action:))
        
        alert.addAction(action)
        
        present(alert, animated: true)
        
    }
    
    var textField = UITextField()
       
       func configureTextField(alertTextField:UITextField) -> Void {
           alertTextField.placeholder = "Enter new item..."
           textField = alertTextField
       }
       
       func addNewItem(action: UIAlertAction){
           print("add new item...")
           //get the value from text field
           let title = textField.text
           
           if title != nil {
               //itemArray.append(TodoItem(title: item!, done: false))
               let item = Item(context: self.context)
               item.title = title
               item.done = false
               itemArray.append(item)
               do{
                   try context.save()
               }catch{
                   print(error)
               }
               tableView.reloadData()
           }
       }}

