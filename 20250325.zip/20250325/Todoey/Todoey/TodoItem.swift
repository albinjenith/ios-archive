//
//  TodoItem.swift
//  Todoey
//
//  Created by admin on 27/3/25.
//

import Foundation

struct TodoItem{
    var title : String
    var done : Bool
}
